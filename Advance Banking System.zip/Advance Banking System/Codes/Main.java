
import java.util.Scanner;

abstract class BankAccount {

    double balance = 100000;
    int pin = 1234;

    abstract void deposit(double amount);

    abstract void withdraw(double amount);

    abstract void calculateInterest();

    abstract void Name();

    boolean verifyPin() {
        Scanner sc = new Scanner(System.in);
        int attempts = 3;

        while (attempts > 0) {
            System.out.print("Enter PIN: ");
            int userPin = sc.nextInt();

            if (userPin == pin) {
                return true;
            } else {
                attempts--;
                System.out.println("Wrong PIN! Attempts left: " + attempts);
            }
        }

        System.out.println("Account blocked due to wrong PIN!");
        return false;
    }

    void showBalance() {
        System.out.println("Current Balance: " + balance);
    }
}
//Saving Account

class SA extends BankAccount {

    @Override
    void Name() {
        System.out.println("==============================");
        System.out.println("     Welcome Mr Moeez        ");
        System.out.println("  It is your saving account   ");
        System.out.println("==============================");
    }

    @Override
    void deposit(double amount) {
        balance += amount;
        System.out.println("Amount deposited successfully.");
    }

    @Override
    void withdraw(double amount) {

        if (verifyPin()) {
            if (amount <= balance) {
                balance -= amount;
                System.out.println("Withdraw successful.");
            } else {
                System.out.println("Insufficient Balance.");
            }
        }
    }

    @Override
    void calculateInterest() {
        double interest = balance * 0.04;
        balance = balance + interest;
        System.out.println("Interest: " + interest);
        System.out.println("New balance with interest: " + balance);
    }
}
//Current account 

class CA extends BankAccount {

    @Override
    void Name() {
        System.out.println("==============================");
        System.out.println("       Welcome Mr Musa       ");
        System.out.println("  It is your saving account   ");
        System.out.println("==============================");
    }

    @Override
    void deposit(double amount) {
        balance += amount;
        System.out.println("Amount deposited successfully.");
    }

    @Override
    void withdraw(double amount) {

        if (verifyPin()) {
            if (amount <= balance) {
                balance -= amount;
                System.out.println("Withdraw successful.");
            } else {
                System.out.println("Insufficient Balance.");
            }
        }
    }

    @Override
    void calculateInterest() {
        double interest = balance * 0.02;
        balance = balance + interest;
        System.out.println("Interest: " + interest);
        System.out.println("New balance with interest: " + balance);
    }
}
//fixed deposite account

class FDA extends BankAccount {

    @Override
    void Name() {
        System.out.println("==============================");
        System.out.println("     Welcome Mr Farukh       ");
        System.out.println("  It is your saving account   ");
        System.out.println("==============================");
    }

    @Override
    void deposit(double amount) {
        balance += amount;
        System.out.println("Amount deposited in Fixed Deposit.");
    }

    @Override
    void withdraw(double amount) {
        System.out.println("In fixed deposite account you can't withdraw amount before time duration");
    }

    @Override
    void calculateInterest() {
        int time;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter time duration in month you open this account :");
        time = sc.nextInt();
        if (time < 1) {
            double interest = balance * 0.07;
            balance = balance + interest;
            System.out.println("Interest: " + interest);
            System.out.println("New balance with interest: " + balance);
            time++;
        } else if (time > 6 || time <= 1) {
            double interest = balance * 0.010;
            balance = balance + interest;
            System.out.println("Interest: " + interest);
            System.out.println("New balance with interest: " + balance);
            time++;
        } else if (time <= 12 && time > 6) {
            double interest = balance * 0.013;
            balance = balance + interest;
            System.out.println("Interest: " + interest);
            System.out.println("New balance with interest: " + balance);
            time++;
        }

    }
}

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int savingsAccNo = 11112121;
        int currentAccNo = 22221111;
        int fdAccNo = 33333131;

        System.out.println("===================================");
        System.out.println("===== ADVANCED BANKING SYSTEM =====");
        System.out.println("===================================");

        System.out.print("Enter Account Number: ");
        int acc = sc.nextInt();
        BankAccount account;

        if (acc == savingsAccNo) {
            account = new SA();
            account.Name();
        } else if (acc == currentAccNo) {
            account = new CA();
            account.Name();
        } else if (acc == fdAccNo) {
            account = new FDA();
            account.Name();
        } else {
            System.out.println("Invalid Account Number!");
            return;
        }

        while (true) {

            System.out.println("\n1 Deposit");
            System.out.println("2 Withdraw");
            System.out.println("3 Show Balance");
            System.out.println("4 Calculate Interest");
            System.out.println("5 Exit");

            System.out.print("Choose option: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1 -> {

                    System.out.print("Enter amount: ");
                    double dep = sc.nextDouble();
                    account.deposit(dep);
                }

                case 2 -> {
                    System.out.print("Enter amount: ");
                    double wit = sc.nextDouble();
                    account.withdraw(wit);
                }

                case 3 ->
                    account.showBalance();

                case 4 ->
                    account.calculateInterest();

                case 5 -> {
                    System.out.println("Thank you for using Bank System.");
                    return;
                }

                default ->
                    System.out.println("Invalid option");
            }
        }
    }
}
